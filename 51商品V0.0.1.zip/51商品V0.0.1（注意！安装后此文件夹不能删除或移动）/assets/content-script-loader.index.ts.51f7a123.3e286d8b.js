(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.51f7a123.js")
    );
  })().catch(console.error);

})();
