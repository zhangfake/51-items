(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.232a439a.js")
    );
  })().catch(console.error);

})();
